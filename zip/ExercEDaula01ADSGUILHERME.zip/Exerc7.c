#include <stdio.h>
#include <stdlib.h>

int main(){

    int i = 7;

    while (i <= 100) {

        printf("Valor de i: %d\n", i);
        i++;
    }

    printf("\n\n");
    
    system("pause");
    return 0;
}